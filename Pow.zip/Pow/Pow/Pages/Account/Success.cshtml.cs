﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Pow.Pages.Account
{
    public class SuccessModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
