﻿namespace Pow.Models
{
    public class Reporte
    {
        public int Id { get; set; }
        public string Tipo { get; set; }
        public DateTime FechaCreacion { get; set; }
    }
}
